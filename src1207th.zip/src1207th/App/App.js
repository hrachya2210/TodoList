import React, {Component} from 'react';
import ToDoList from '../ToDoList/ToDoList';

class App extends Component {
    constructor () {
        super() 
        this.state = {
            maxId: 3,
            list: [
              {   
                id: 1,
                title: "todo1",
                important: false,
                done: false,
              },
              {   
                id: 2,
                title: "todo2",
                important: false,
                done: false,
              },
              {   
                id: 3,
                title: "todo3",
                important: false,
                done: false,
              },
            ]
        }
    }
    
    render (){
      return (
        <div>
          <h1>TODO List</h1>
          <h5>{5} things to do and {3} done</h5>
          <ToDoList />
        </div>
      )
    } 
} 
export default App;