import React, {Component} from 'react';
import TodoItem from '../ToDoList/TodoItem';
import AddNewTodoForm from '../AddNewTodoForm/AddNewTodoForm'

class App extends Component {
    constructor () {
        super() 
        this.maxId= 1;
        this.state = {
            
            list: [
                this.createTodoItem("Get UP"),
                this.createTodoItem("Wash up"),
                this.createTodoItem("Eat breakfast"),
                this.createTodoItem("Go to work")
            ]
        }
    }

    createTodoItem = (title) => {
        return {
            id: this.maxId++,
            title: title,
            important: false,
            done: false
        }
    } 

    addNewList = (newTodoTitle) => {
        const newTodoItem = this.createTodoItem(newTodoTitle);
        this.setState( ({list}) =>{
            const  newTodoList = [...list, newTodoItem];
                return {
                    list: newTodoList
                }
            } 
        )
    }

    toggleImportant = (id) => {
        this.setState (({list}) => {
            
            const  idx = list.findIndex ((item) => item.id === id);
            
            const oldItem = list[idx];
            
            const newItem = {...oldItem, important: !oldItem.important};

            const newList = [...list.slice(0, idx), newItem, ...list.slice(idx+1)];
            return {
               list: newList
            }
        })
    }

    makeDone = (id) => {
        this.setState (({list}) => {
            
            const  idx = list.findIndex ((item) => item.id === id);
            
            const oldItem = list[idx];
            
            const newItem = {...oldItem, done: !oldItem.done};

            const newList = [...list.slice(0, idx), newItem, ...list.slice(idx+1)];
            return {
               list: newList
            }
        })
    }

    renderTodoList = (toDoItems) => {
        return  toDoItems.map ((item)=>{
            return (<TodoItem makeDone= {this.makeDone} toggleImportant = {this.toggleImportant} key={item.id}  todoItem={item} />);
        })
    }

    
    render (){
        return (
            <div>
                <h1>TODO List</h1>
                <h5>{this.maxId} things to do and {3} done</h5>
                {this.renderTodoList(this.state.list)} 
                <AddNewTodoForm addNewList={this.addNewList} />
            </div>
        )
    } 
} 
export default App;