import React, {Component} from 'react';
import './TodoItem.css';

class TodoItem extends Component {

    handleImportant = () => {
        const  { toggleImportant, todoItem } = this.props;
        if (!todoItem.done) {
            toggleImportant(todoItem.id);
        }
        
    }

    handleDone = () => {
        const  { makeDone, todoItem } = this.props;
        if (!todoItem.done) {
            makeDone(todoItem.id);
        }
        
    }

    render () {
        const {todoItem} = this.props; //?????????????????????
        const {id, title,important, done} = todoItem;
        let classes ='';
        if (important) {
            classes =classes+' important'
        }
        if (done) {
            classes =classes+' done'
        }
        return (
            <div className = "todoRow">
                <span onClick = {this.handleDone} className={classes}>{id}.{title}</span> 
                <button onClick = {this.handleImportant}  className="button">Important</button>
            </div>
        )
    }
}
export default TodoItem;