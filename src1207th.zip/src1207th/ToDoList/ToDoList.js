import React, {Component} from 'react';
import TodoItem from './TodoItem';

class ToDoList extends Component {
    constructor () {
        super ()
        this.state = {
            newTodoText: ''
        }
    }

    

    createNewTodoItem = () => {
        const {newTodoText} = this.state;
        return {
            id: this.state.maxid +1,
            text: newTodoText,
            important: false,
            done: false
        }
    }

    newTodoStateChange = (event) => {
        this.setState (
            {
                newTodoText: event.target.value
            }
        )
        
    }
    // createNewTodoList = (event) => {
    //     event.preventDefault();
    //     const newTodoItem = this.createNewTodoItem();
    //     const {list} = this.state;
    //     const newList = [...list, newTodoItem];
    //     console.log (newList);
    //     this.setState (({list,newTodoText})=>{
    //             return {
    //                 list: newList,
    //                 newTodoText: "",
    //                 maxid: this.state.maxid+1
    //             }
                
    //         }
    //     )
    //     console.log(this.state.list);
    // }


    render () {
        const {list} = this.props;
        return (
            <div> 
                <h3></h3>                
                
               
               
                
            </div>
            
        )
    }
}

export default ToDoList;